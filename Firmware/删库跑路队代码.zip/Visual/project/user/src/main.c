/*
 *      @File: main.c
 *
 *      @Team: ɾ����·��
 *      @Author: ���
 */


#include "zf_common_headfile.h"
#include "dvp.h"
#include "ov.h"
#include "sram.h"
#include "MyCan.h"
#include "img_process.h"

const uint16_t img_height = ROW_TFT_HEIGHT;
const uint16_t img_width = ROW_TFT_WIDTH / 2;

uint8_t dvp_img_finish_flag = 0;
extern __aligned(4) uint16 img_dvp[ROW_TFT_HEIGHT][ROW_TFT_WIDTH / 2];
uint8_t red_binary_dvp_img[ROW_TFT_HEIGHT][ROW_TFT_WIDTH / 2];

extern RedLinePos red_line_pos[10];
// ֱ��ͼ
short hist_gram[256];

extern bool is_scan;

void Blink(uint16_t _times)
{
    static int i = 0;
    if (i >= _times)
    {
        gpio_toggle_level(E7);
        i = 0;
    }
    i++;
}

typedef enum
{
    FlASH_192_SRAM_128 = 0,
    FLASH_224_SRAM_96,
    FLASH_256_SRAM_64,
    FLASH_288_RAM_32
} FLASH_SRAM_DEFIN;

//note: this operation will take effect after reset
void Config_Flash_SRAM(FLASH_SRAM_DEFIN SetFlashSRAM)
{
    uint8_t UserByte = FLASH_GetUserOptionByte() & 0xff; //get user option byte

    switch(SetFlashSRAM)
    {
    case 0:
        UserByte &= ~(0xc0); // SRAM_CODE_MODE = 00
        break;
    case 1:
        UserByte &= ~(0xc0); // SRAM_CODE_MODE = 00
        UserByte |= 0x7f;    // SRAM_CODE_MODE = 01
        break;
    case 2:
        UserByte &= ~(0xc0); // SRAM_CODE_MODE = 00
        UserByte |= 0xbf;    // SRAM_CODE_MODE = 10
        break;
    case 3:
        UserByte |= 0xff;    // SRAM_CODE_MODE = 11
        break;
    default:
        break;
    }

    FLASH_Unlock();
    FLASH_ProgramOptionByteData(0x1ffff802, UserByte);
    FLASH_Lock();
}

// ��ȡͼƬ��ֱ��ͼ
void GetHistGram (uint8_t width, uint8_t height)
{
    for (int i_ = 0; i_ < 256; ++i_)
    {
        hist_gram[i_] = 0;
    }
    for (int i_ = 0; i_ < height; ++i_)
    {
        for (uint8_t j_ = 0; j_ < width; ++j_)
        {
            hist_gram[binary_dvp_img[i_][j_]]++;
        }
    }
}

// ��򷨻�ȡ��ֵ
unsigned char OTSUThreshold ()
{
    int X, Y, amount = 0;
    int pixel_back = 0, pixel_fore = 0, pixel_integral_back = 0, pixel_integral_fore = 0, pixel_integral = 0;
    double OmegaBack, OmegaFore, MicroBack, MicroFore, SigmaB, Sigma; // ��䷽��;
    int pixel_min_value, pixel_max_value;
    int threshold = 0;

    for (pixel_min_value = 0; pixel_min_value < 256 && hist_gram[pixel_min_value] == 0; pixel_min_value++)
        ;
    for (pixel_max_value = 255; pixel_max_value > pixel_min_value && hist_gram[pixel_max_value] == 0; pixel_max_value--)
        ;
    if (pixel_max_value == pixel_min_value)
        return pixel_max_value; // ͼ����ֻ��һ����ɫ
    if (pixel_min_value + 1 == pixel_max_value)
        return pixel_min_value; // ͼ����ֻ�ж�����ɫ

    for (Y = pixel_min_value; Y <= pixel_max_value; Y++)
        amount += hist_gram[Y]; //  ��������

    pixel_integral = 0;
    for (Y = pixel_min_value; Y <= pixel_max_value; Y++)
        pixel_integral += hist_gram[Y] * Y;
    SigmaB = -1;
    for (Y = pixel_min_value; Y < pixel_max_value; Y++)
    {
        pixel_back = pixel_back + hist_gram[Y];
        pixel_fore = amount - pixel_back;
        OmegaBack = (double) pixel_back / amount;
        OmegaFore = (double) pixel_fore / amount;
        pixel_integral_back += hist_gram[Y] * Y;
        pixel_integral_fore = pixel_integral - pixel_integral_back;
        MicroBack = (double) pixel_integral_back / pixel_back;
        MicroFore = (double) pixel_integral_fore / pixel_fore;
        Sigma = OmegaBack * OmegaFore * (MicroBack - MicroFore) * (MicroBack - MicroFore);
        if (Sigma > SigmaB)
        {
            SigmaB = Sigma;
            threshold = Y;
        }
    }
    return threshold;
}

/*
 * ��ֵ������
 */
void BinaryzationProcess (int rows, int cols, unsigned int threshold_value)
{
    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < cols; ++j)
        {
            binary_dvp_img[i][j] = binary_dvp_img[i][j] > threshold_value ? 255 : 0;
        }
    }
}

void ToGray()
{
    uint32_t r, g, b;
    uint16_t src_cols = img_width;
    for (uint16_t i = 0; i < img_height; i++)
    {
        for (uint16_t j = 0; j < src_cols; ++j)
        {
            uint16 pixel;
            //��ȡָ���������������
            pixel = img_dvp[i][j];
            //��ΪR5G3�Ǵ洢�ڵͰ�λ G3B5�Ǵ洢�ڸ߰�λ
            //��Ϊ�����Ƚ�λ�ý��н��������ڻ�ȡÿ������������
            pixel = ((pixel&0xff)<<8) |(pixel>>8);
            r = pixel>>11;
            g = (pixel>>5)&0x3f;
            b = pixel&0x1f;
            binary_dvp_img[i][j] = (r*19595 + g*38469 + b*7472) >> 16;
        }
    }

}

void SendImgToUart(const uint8_t* _img, uint8_t _width, uint8_t _height)
{
    uart_write_byte(UART_7, 0x01); uart_write_byte(UART_7, 0xFE);
    uart_write_buffer(UART_7, _img, _width * _height);
    uart_write_byte(UART_7, 0xFE); uart_write_byte(UART_7, 0x01);
}

void Init(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    tft180_init();
    // CAN��ʼ��
    CAN_Mode_Init( CAN_SJW_1tq, CAN_BS2_5tq, CAN_BS1_6tq, 12, CAN_Mode_Normal );
    gpio_init(E7, GPO, GPIO_LOW, GPO_PUSH_PULL);
    // �����ʼ��
    pwm_init(TIM5_PWM_CH1_A0, 50, 1000);
    // FSMC_SRAM_Init();
    // ��ʼ��UART
    uart_init(UART_7, 115200, UART7_TX_C2, UART7_RX_C3);
}

int main(void)
{
    interrupt_global_disable();             // �ر����ж�
    Config_Flash_SRAM(FLASH_256_SRAM_64);
    clock_init(SYSTEM_CLOCK_144M);          // ��ر���������ϵͳʱ�ӡ�
    debug_init();                           // ��ر��������������ڳ�ʼ��MPU ʱ�� ���Դ���
    Init();
    interrupt_global_enable();              // ���ж������
    while (OV2640_Init())
    {
        printf("Camera Err\r\n");
        Delay_Ms(1000);
    }
    RGB565_Mode_Init();
    DVP_OV_Init();

    uint8_t px;
    uint8_t pxbuf[30];
    int _ret_no_zero = 0;
    int _max_ret = 0;
    int _last_ret = -1;
    while(1)
    {

        if (dvp_img_finish_flag && is_scan)
        {

            SeekRed(red_line_pos, img_dvp[0], img_width, img_height, (uint8_t*)red_binary_dvp_img);
            int16_t ret = SeekRedLine((uint8_t*)red_binary_dvp_img, img_width, img_height);
            if (ret != 0)
            {
                _ret_no_zero++;
                if (_max_ret < ret)
                {
                    _max_ret = ret;
                }
                if (_ret_no_zero > 200)
                {
                    _last_ret = _max_ret;
                }
                Solve(_last_ret);
            }
            tft180_show_int(0, 0, ret, 3);
            //tft180_show_rgb565_image(0, 0, img_dvp[0], img_width, img_height, img_width, img_height, 1);
            //ToGray();
            //SendImgToUart((uint8_t*)red_binary_dvp_img, img_width, img_height);
            //GetHistGram(img_width, img_height);
            //uint8_t thredshold = OTSUThreshold();
            //BinaryzationProcess(ROW_TFT_HEIGHT, img_width, 20);
            tft180_show_gray_image(0, 0, red_binary_dvp_img[0], img_width, img_height, img_width, img_height, 0);
            //Zbar_Test(binary_dvp_img[0], img_width, img_height);
            //tft180_show_string(0, 0, "hello world!");
            dvp_img_finish_flag = 0;

        }
        //Blink(5000);
        system_delay_ms(2);
    }
}

void Solve(int _last_value)
{
    char send_msg[] = "PIC *#";
    send_msg[4] = _last_value;
    CAN_Send_Msg(send_msg, 6, MAIN_CONTROLER_FILTER_ID_A);
    is_scan = false;
}





