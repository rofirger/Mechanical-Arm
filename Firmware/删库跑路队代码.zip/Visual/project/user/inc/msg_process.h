/*
 *      @File: msg_process.h
 *
 *      @Team: ɾ����·��
 *      @Author: ���
 */

#ifndef _MSG_PROCESS_H_
#define _MSG_PROCESS_H_
void CAN_MsgProcess(char* _can_msg);
void GetGoods();
void PutGoods();
#endif
